import test from 'node:test';
import assert from 'node:assert/strict';
import { encryptJson, decryptJson, pkcePair, randomId } from '../src/crypto.js';
test('encrypted JSON round-trips',()=>{const secret='a'.repeat(48),v={access_token:'secret',n:1};const enc=encryptJson(v,secret);assert.notEqual(enc,JSON.stringify(v));assert.deepEqual(decryptJson(enc,secret),v);});
test('PKCE verifier/challenge are generated',()=>{const p=pkcePair();assert.ok(p.verifier.length>40);assert.ok(p.challenge.length>30);assert.notEqual(p.verifier,p.challenge);});
test('IDs retain prefixes and are unique',()=>{const a=randomId('post_'),b=randomId('post_');assert.match(a,/^post_/);assert.notEqual(a,b);});
