import fs from 'node:fs'; import path from 'node:path'; import { pool } from '../src/db.js';
for(const file of fs.readdirSync('migrations').filter(x=>x.endsWith('.sql')).sort())await pool.query(fs.readFileSync(path.join('migrations',file),'utf8'));
const {ensureOwner}=await import('../src/auth.js'); await ensureOwner();
if(String(process.env.SEED_MOCK_DATA||'true').toLowerCase()==='true'){
 const {one,query}=await import('../src/db.js'); const rows=[['mock_instagram','instagram','Instagram Brand','@acmebrand','Business'],['mock_tiktok','tiktok','TikTok Creator','@acme','Creator'],['mock_youtube','youtube','Acme Studio','Acme Studio','Channel'],['mock_facebook','facebook','Acme Page','Acme Page','Page']];
 for(const r of rows)if(!(await one('SELECT id FROM social_accounts WHERE id=$1',[r[0]])))await query("INSERT INTO social_accounts(id,platform,display_name,username,account_type,status,last_sync) VALUES($1,$2,$3,$4,$5,'CONNECTED',NOW())",r);
}
await import('../src/server.js');
