import { one, query, pool } from '../src/db.js';
const rows=[['mock_instagram','instagram','Instagram Brand','@acmebrand','Business','CONNECTED'],['mock_tiktok','tiktok','TikTok Creator','@acme','Creator','CONNECTED'],['mock_youtube','youtube','Acme Studio','Acme Studio','Channel','CONNECTED'],['mock_facebook','facebook','Acme Page','Acme Page','Page','CONNECTED']];
for(const r of rows){if(!(await one('SELECT id FROM social_accounts WHERE id=$1',[r[0]])))await query('INSERT INTO social_accounts(id,platform,display_name,username,account_type,status,last_sync) VALUES($1,$2,$3,$4,$5,$6,NOW())',r);}
console.log('Seed complete'); await pool.end();
