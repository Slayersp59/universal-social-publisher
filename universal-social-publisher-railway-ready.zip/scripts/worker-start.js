import fs from 'node:fs'; import path from 'node:path'; import { pool } from '../src/db.js';
for(const file of fs.readdirSync('migrations').filter(x=>x.endsWith('.sql')).sort())await pool.query(fs.readFileSync(path.join('migrations',file),'utf8'));
await import('../src/worker.js');
