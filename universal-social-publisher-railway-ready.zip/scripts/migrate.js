import fs from 'node:fs';
import path from 'node:path';
import { pool } from '../src/db.js';
const dir=path.resolve('migrations');
for (const file of fs.readdirSync(dir).filter(x=>x.endsWith('.sql')).sort()) {
  console.log('Applying',file); await pool.query(fs.readFileSync(path.join(dir,file),'utf8'));
}
await pool.end(); console.log('Migrations complete');
