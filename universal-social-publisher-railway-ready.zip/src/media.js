import { spawn } from 'node:child_process';
import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';
import { randomId } from './crypto.js';
import { one, query } from './db.js';
import { downloadToFile, uploadFile } from './storage.js';

function run(cmd,args){ return new Promise((resolve,reject)=>{ const p=spawn(cmd,args); let out='',err=''; p.stdout.on('data',d=>out+=d); p.stderr.on('data',d=>err+=d); p.on('error',reject); p.on('close',c=>c===0?resolve(out):reject(new Error(`${cmd} failed: ${err.slice(-2000)}`))); }); }
function ratio(s){ if(!s) return null; const [a,b]=String(s).split('/').map(Number); return b?a/b:null; }
export async function analyzeMedia(mediaId){
  const media=await one('SELECT * FROM media_assets WHERE id=$1',[mediaId]); if(!media) throw new Error('Media not found');
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'usp-')); const input=path.join(dir,'input');
  try{
    await query("UPDATE media_assets SET status='PROCESSING',updated_at=NOW() WHERE id=$1",[mediaId]); await downloadToFile(media.object_key,input);
    const raw=await run('ffprobe',['-v','error','-show_streams','-show_format','-of','json',input]); const info=JSON.parse(raw); const v=info.streams?.find(s=>s.codec_type==='video')||{}; const a=info.streams?.find(s=>s.codec_type==='audio')||{};
    await query(`UPDATE media_assets SET width=$1,height=$2,duration_seconds=$3,frame_rate=$4,video_codec=$5,audio_codec=$6,bitrate=$7,status='READY',error=NULL,updated_at=NOW() WHERE id=$8`,[v.width||null,v.height||null,Number(info.format?.duration)||null,ratio(v.avg_frame_rate),v.codec_name||null,a.codec_name||null,Number(info.format?.bit_rate)||null,mediaId]);
    const variants=[['9:16',1080,1920],['1:1',1080,1080],['4:5',1080,1350],['16:9',1920,1080]];
    for(const [ar,w,h] of variants){
      const id=randomId('var_'), key=`variants/${mediaId}/${ar.replace(':','x')}.mp4`, out=path.join(dir,`${id}.mp4`);
      await query(`INSERT INTO media_variants(id,media_id,aspect_ratio,strategy,object_key,status) VALUES($1,$2,$3,'fit',$4,'PROCESSING') ON CONFLICT DO NOTHING`,[id,mediaId,ar,key]);
      try{
        await run('ffmpeg',['-y','-i',input,'-vf',`scale=${w}:${h}:force_original_aspect_ratio=decrease,pad=${w}:${h}:(ow-iw)/2:(oh-ih)/2`,'-c:v','libx264','-preset','veryfast','-crf','23','-c:a','aac','-movflags','+faststart',out]);
        await uploadFile(key,out,'video/mp4'); const stat=fs.statSync(out); await query(`UPDATE media_variants SET size_bytes=$1,width=$2,height=$3,status='READY',updated_at=NOW() WHERE media_id=$4 AND aspect_ratio=$5`,[stat.size,w,h,mediaId,ar]);
      }catch(e){ await query(`UPDATE media_variants SET status='FAILED',error=$1,updated_at=NOW() WHERE media_id=$2 AND aspect_ratio=$3`,[String(e.message||e),mediaId,ar]); }
    }
  }catch(e){ await query(`UPDATE media_assets SET status='FAILED',error=$1,updated_at=NOW() WHERE id=$2`,[String(e.message||e),mediaId]); throw e; }
  finally{ fs.rmSync(dir,{recursive:true,force:true}); }
}
