import { Queue } from 'bullmq';
import IORedis from 'ioredis';
import { config } from './config.js';
let connection, publishingQueue, mediaQueue;
export function redisConnection(){ if(!connection){ if(!config.redisUrl) throw new Error('REDIS_URL is not configured'); connection=new IORedis(config.redisUrl,{maxRetriesPerRequest:null,enableReadyCheck:false}); } return connection; }
export function queues(){
  const c=redisConnection();
  publishingQueue ||= new Queue('publishing',{connection:c,defaultJobOptions:{removeOnComplete:{count:1000},removeOnFail:{count:1000}}});
  mediaQueue ||= new Queue('media-processing',{connection:c,defaultJobOptions:{removeOnComplete:{count:500},removeOnFail:{count:500}}});
  return {publishingQueue,mediaQueue};
}
export async function enqueueTarget(targetId,scheduledAt=null){ const delay=scheduledAt?Math.max(0,new Date(scheduledAt).getTime()-Date.now()):0; return queues().publishingQueue.add('publish-target',{targetId},{delay,attempts:4,backoff:{type:'exponential',delay:1500}}); }
export async function enqueueMediaAnalysis(mediaId){ return queues().mediaQueue.add('analyze-media',{mediaId},{attempts:2,backoff:{type:'exponential',delay:2000}}); }
