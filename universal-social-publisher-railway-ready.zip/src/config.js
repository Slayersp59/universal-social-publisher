import fs from 'node:fs';
for (const line of fs.existsSync('.env') ? fs.readFileSync('.env','utf8').split(/\r?\n/) : []) {
  const m=line.match(/^([A-Z0-9_]+)=(.*)$/); if(m && !process.env[m[1]]) process.env[m[1]]=m[2];
}
export const config = {
  port: Number(process.env.PORT || 3000),
  appUrl: process.env.APP_URL || 'http://localhost:3000',
  nodeEnv: process.env.NODE_ENV || 'development',
  databaseUrl: process.env.DATABASE_URL || '',
  redisUrl: process.env.REDIS_URL || '',
  tokenEncryptionKey: process.env.TOKEN_ENCRYPTION_KEY || '',
  publishMode: process.env.PUBLISH_MODE || 'mock',
  authDisabled: String(process.env.AUTH_DISABLED || 'false').toLowerCase() === 'true',
  ownerEmail: process.env.OWNER_EMAIL || '',
  ownerPasswordHash: process.env.OWNER_PASSWORD_HASH || '',
  sessionDays: Number(process.env.SESSION_DAYS || 14),
  r2: {
    accountId: process.env.R2_ACCOUNT_ID || '',
    bucket: process.env.R2_BUCKET || '',
    accessKeyId: process.env.R2_ACCESS_KEY_ID || '',
    secretAccessKey: process.env.R2_SECRET_ACCESS_KEY || '',
    publicBaseUrl: (process.env.R2_PUBLIC_BASE_URL || '').replace(/\/$/, '')
  }
};
export function requireProductionConfig(){
  const missing=[];
  for (const [name,value] of [['DATABASE_URL',config.databaseUrl],['REDIS_URL',config.redisUrl],['TOKEN_ENCRYPTION_KEY',config.tokenEncryptionKey],['R2_ACCOUNT_ID',config.r2.accountId],['R2_BUCKET',config.r2.bucket],['R2_ACCESS_KEY_ID',config.r2.accessKeyId],['R2_SECRET_ACCESS_KEY',config.r2.secretAccessKey]]) if(!value) missing.push(name);
  if (!config.authDisabled) for (const [name,value] of [['OWNER_EMAIL',config.ownerEmail],['OWNER_PASSWORD_HASH',config.ownerPasswordHash]]) if(!value) missing.push(name);
  return missing;
}
