import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomId } from './crypto.js';
import { config, requireProductionConfig } from './config.js';
import { one, many, query, tx } from './db.js';
import { capabilities, startOAuth, finishOAuth } from './platforms.js';
import { presignUpload, presignDownload, headObject } from './storage.js';
import { enqueueMediaAnalysis, enqueueTarget } from './queue.js';
import { login, logout, getSession, setSessionCookie, clearSessionCookie, validCsrf } from './auth.js';

const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),PUBLIC=path.join(ROOT,'public');
function json(res,status,data){const body=JSON.stringify(data);res.writeHead(status,{'content-type':'application/json','content-length':Buffer.byteLength(body),'cache-control':'no-store'});res.end(body);}
async function readJson(req,limit=2_000_000){let size=0;const chunks=[];for await(const c of req){size+=c.length;if(size>limit)throw Object.assign(new Error('Request too large'),{status:413});chunks.push(c)}return chunks.length?JSON.parse(Buffer.concat(chunks).toString('utf8')):{};}
function cleanName(n='upload.bin'){return n.replace(/[^a-zA-Z0-9._-]+/g,'_').slice(0,160)}
function mimeFor(p){const e=path.extname(p).toLowerCase();return e==='.html'?'text/html; charset=utf-8':e==='.js'?'text/javascript':e==='.css'?'text/css':e==='.json'?'application/json':e==='.svg'?'image/svg+xml':'application/octet-stream'}
async function audit(session,action,type,id,metadata={}){await query('INSERT INTO audit_logs(id,user_id,action,entity_type,entity_id,metadata) VALUES($1,$2,$3,$4,$5,$6)',[randomId('audit_'),session?.user_id||session?.user?.id||null,action,type,id,JSON.stringify(metadata)]);}

async function publicApi(req,res,url){
  if(req.method==='GET'&&url.pathname==='/api/health'){
    let db=false,redis=false; try{await one('SELECT 1 AS ok');db=true}catch{} try{const {redisConnection}=await import('./queue.js');await redisConnection().ping();redis=true}catch{}
    const missing=requireProductionConfig();return json(res,missing.length?503:200,{ok:!missing.length,database:db,redis,mode:config.publishMode,missing,time:new Date().toISOString()});
  }
  if(req.method==='POST'&&url.pathname==='/api/auth/login'){const b=await readJson(req);const s=await login(b.email,b.password);if(!s)return json(res,401,{error:'Invalid email or password'});setSessionCookie(res,s);return json(res,200,{user:s.user,csrf:s.csrf});}
  if(req.method==='GET'&&url.pathname.match(/^\/api\/oauth\/[^/]+\/callback$/)){const m=url.pathname.match(/^\/api\/oauth\/([^/]+)\/callback$/);try{await finishOAuth(m[1],url.searchParams.get('code'),url.searchParams.get('state'));res.writeHead(302,{location:'/'});return res.end()}catch(e){return json(res,400,{error:e.message});}}
  return false;
}

async function api(req,res,url,session){
  if(req.method==='GET'&&url.pathname==='/api/auth/session')return json(res,200,{authenticated:true,user:{id:session.user_id||session.user.id,email:session.email||session.user.email,role:session.role||session.user.role},csrf:session.csrf});
  if(req.method==='POST'&&url.pathname==='/api/auth/logout'){await logout(req);clearSessionCookie(res);return json(res,200,{ok:true});}
  if(req.method==='GET'&&url.pathname==='/api/platforms')return json(res,200,capabilities);
  if(req.method==='GET'&&url.pathname==='/api/accounts')return json(res,200,await many('SELECT id,platform,display_name,username,account_type,status,token_expires_at,last_sync,created_at,updated_at FROM social_accounts ORDER BY created_at'));
  if(req.method==='POST'&&url.pathname==='/api/accounts/mock/connect'){const b=await readJson(req),id=`mock_${String(b.platform||'demo').toLowerCase()}_${Date.now()}`;await query("INSERT INTO social_accounts(id,platform,display_name,username,account_type,status,last_sync) VALUES($1,$2,$3,$4,'Mock','CONNECTED',NOW())",[id,String(b.platform).toLowerCase(),b.displayName||`${b.platform} demo`,b.username||'@demo']);await audit(session,'ACCOUNT_CONNECT','SocialAccount',id,{platform:b.platform,mock:true});return json(res,201,{id});}
  if(req.method==='POST'&&url.pathname==='/api/media/upload-url'){
    const b=await readJson(req);const mime=String(b.contentType||'');if(!mime.startsWith('video/'))return json(res,415,{error:'Only video uploads are accepted'});const id=randomId('media_'),name=cleanName(b.fileName),key=`masters/${id}/${name}`;await query("INSERT INTO media_assets(id,original_name,object_key,mime_type,size_bytes,status) VALUES($1,$2,$3,$4,$5,'UPLOADING')",[id,name,key,mime,Number(b.size)||null]);const uploadUrl=await presignUpload(key,mime);await audit(session,'MEDIA_UPLOAD_STARTED','MediaAsset',id,{name,size:b.size});return json(res,201,{id,key,uploadUrl,method:'PUT',headers:{'Content-Type':mime}});
  }
  if(req.method==='POST'&&url.pathname==='/api/media/complete'){
    const b=await readJson(req),media=await one('SELECT * FROM media_assets WHERE id=$1',[b.mediaId]);if(!media)return json(res,404,{error:'Media not found'});const head=await headObject(media.object_key);await query("UPDATE media_assets SET size_bytes=$1,status='UPLOADED',updated_at=NOW() WHERE id=$2",[Number(head.ContentLength)||media.size_bytes,media.id]);await enqueueMediaAnalysis(media.id);return json(res,202,{id:media.id,status:'PROCESSING'});
  }
  if(req.method==='GET'&&url.pathname==='/api/media'){const rows=await many('SELECT id,original_name,mime_type,size_bytes,width,height,duration_seconds,status,error,created_at FROM media_assets ORDER BY created_at DESC');return json(res,200,rows);}
  let m=url.pathname.match(/^\/api\/media\/([^/]+)\/download$/);if(req.method==='GET'&&m){const media=await one('SELECT * FROM media_assets WHERE id=$1',[m[1]]);if(!media)return json(res,404,{error:'Not found'});return json(res,200,{url:await presignDownload(media.object_key,900)});}
  if(req.method==='POST'&&url.pathname==='/api/posts'){
    const b=await readJson(req);if(!Array.isArray(b.targets)||!b.targets.length)return json(res,400,{error:'At least one target is required'});const id=randomId('post_'),scheduled=b.scheduledAt?new Date(b.scheduledAt):null,status=scheduled?'SCHEDULED':'DRAFT';
    await tx(async c=>{await c.query('INSERT INTO posts(id,title,caption,hashtags,media_id,status,scheduled_at) VALUES($1,$2,$3,$4,$5,$6,$7)',[id,b.title||'',b.caption||'',b.hashtags||'',b.mediaId||null,status,scheduled]);for(const x of b.targets){const acct=await c.query('SELECT id FROM social_accounts WHERE id=$1',[x.accountId]);if(!acct.rows[0])throw new Error(`Account not found: ${x.accountId}`);await c.query('INSERT INTO post_targets(id,post_id,platform,account_id,title,caption,status,scheduled_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8)',[randomId('target_'),id,String(x.platform).toLowerCase(),x.accountId,x.title||b.title||'',x.caption||b.caption||'',status,scheduled]);}});
    if(scheduled){const targets=await many('SELECT id FROM post_targets WHERE post_id=$1',[id]);for(const t of targets)await enqueueTarget(t.id,scheduled);}
    await audit(session,'POST_CREATE','Post',id,{scheduledAt:b.scheduledAt||null,targets:b.targets.length});return json(res,201,{id,status});
  }
  m=url.pathname.match(/^\/api\/posts\/([^/]+)$/);if(req.method==='GET'&&m){const p=await one('SELECT * FROM posts WHERE id=$1',[m[1]]);if(!p)return json(res,404,{error:'Not found'});return json(res,200,{...p,targets:await many('SELECT * FROM post_targets WHERE post_id=$1',[m[1]])});}
  m=url.pathname.match(/^\/api\/posts\/([^/]+)\/publish$/);if(req.method==='POST'&&m){const p=await one('SELECT * FROM posts WHERE id=$1',[m[1]]);if(!p)return json(res,404,{error:'Not found'});const targets=await many("UPDATE post_targets SET status='QUEUED',scheduled_at=NULL,updated_at=NOW() WHERE post_id=$1 AND status IN ('DRAFT','SCHEDULED','ACTION_REQUIRED') RETURNING id",[m[1]]);await query("UPDATE posts SET status='QUEUED',scheduled_at=NULL,updated_at=NOW() WHERE id=$1",[m[1]]);for(const t of targets)await enqueueTarget(t.id);await audit(session,'POST_QUEUE','Post',m[1],{targets:targets.length});return json(res,202,{queued:true,targets:targets.length});}
  if(req.method==='GET'&&url.pathname==='/api/posts')return json(res,200,await many('SELECT * FROM posts ORDER BY created_at DESC LIMIT 100'));
  if(req.method==='GET'&&url.pathname==='/api/dashboard'){const accounts=(await one("SELECT COUNT(*)::int c FROM social_accounts WHERE status='CONNECTED'")).c,scheduled=(await one("SELECT COUNT(*)::int c FROM posts WHERE status='SCHEDULED'")).c,published=(await one("SELECT COUNT(*)::int c FROM post_targets WHERE status='PUBLISHED'")).c,attention=(await one("SELECT COUNT(*)::int c FROM post_targets WHERE status='ACTION_REQUIRED'")).c;return json(res,200,{metrics:{accounts,scheduled,published,attention},targets:await many('SELECT * FROM post_targets ORDER BY updated_at DESC LIMIT 12')});}
  m=url.pathname.match(/^\/api\/oauth\/([^/]+)\/start$/);if(req.method==='POST'&&m){try{return json(res,200,{url:await startOAuth(m[1])})}catch(e){return json(res,400,{error:e.message})}}
  return false;
}

const server=http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,config.appUrl); const pub=await publicApi(req,res,url);if(pub!==false)return;
    const session=await getSession(req);
    if(url.pathname.startsWith('/api/')){if(!session)return json(res,401,{error:'Authentication required'});if(!['GET','HEAD','OPTIONS'].includes(req.method)&&!validCsrf(req,session))return json(res,403,{error:'Invalid CSRF token'});const handled=await api(req,res,url,session);if(handled!==false)return;return json(res,404,{error:'API route not found'});}
    if(url.pathname==='/login.html'){const f=path.join(PUBLIC,'login.html');res.writeHead(200,{'content-type':'text/html; charset=utf-8'});return fs.createReadStream(f).pipe(res);}
    if(!session){res.writeHead(302,{location:'/login.html'});return res.end();}
    const rel=url.pathname==='/'?'index.html':url.pathname.replace(/^\/+/,''),file=path.resolve(PUBLIC,rel);if(!file.startsWith(PUBLIC)||!fs.existsSync(file)||fs.statSync(file).isDirectory()){res.writeHead(404);return res.end('Not found');}res.writeHead(200,{'content-type':mimeFor(file)});fs.createReadStream(file).pipe(res);
  }catch(e){console.error(e);if(!res.headersSent)json(res,e.status||500,{error:e.message||'Internal server error'});else res.end();}
});
server.listen(config.port,'0.0.0.0',()=>console.log(`Universal Social Publisher listening on ${config.port}`));
