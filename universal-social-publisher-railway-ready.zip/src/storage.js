import { S3Client, PutObjectCommand, GetObjectCommand, HeadObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import fs from 'node:fs';
import { pipeline } from 'node:stream/promises';
import { config } from './config.js';

function client(){
  if(!config.r2.accountId||!config.r2.accessKeyId||!config.r2.secretAccessKey) throw new Error('R2 is not configured');
  return new S3Client({region:'auto',endpoint:`https://${config.r2.accountId}.r2.cloudflarestorage.com`,credentials:{accessKeyId:config.r2.accessKeyId,secretAccessKey:config.r2.secretAccessKey}});
}
export async function presignUpload(key,contentType){ return getSignedUrl(client(),new PutObjectCommand({Bucket:config.r2.bucket,Key:key,ContentType:contentType}),{expiresIn:900}); }
export async function presignDownload(key,expiresIn=3600){ return getSignedUrl(client(),new GetObjectCommand({Bucket:config.r2.bucket,Key:key}),{expiresIn}); }
export async function headObject(key){ return client().send(new HeadObjectCommand({Bucket:config.r2.bucket,Key:key})); }
export async function downloadToFile(key,file){ const r=await client().send(new GetObjectCommand({Bucket:config.r2.bucket,Key:key})); await pipeline(r.Body,fs.createWriteStream(file)); }
export async function uploadFile(key,file,contentType='application/octet-stream'){ await client().send(new PutObjectCommand({Bucket:config.r2.bucket,Key:key,Body:fs.createReadStream(file),ContentType:contentType})); }
export function publicUrl(key){ return config.r2.publicBaseUrl ? `${config.r2.publicBaseUrl}/${key.split('/').map(encodeURIComponent).join('/')}` : null; }
