import fs from 'node:fs';
import { randomId, pkcePair, encryptJson, decryptJson } from './crypto.js';
import { one, query } from './db.js';
import { config } from './config.js';

const now=()=>new Date().toISOString();
export const capabilities = {
  youtube:{video:true,shortVideo:true,scheduling:false,analytics:true,thumbnail:true,privacy:true},
  instagram:{video:true,shortVideo:true,scheduling:false,analytics:true,thumbnail:true,privacy:false},
  facebook:{video:true,shortVideo:true,scheduling:false,analytics:true,thumbnail:true,privacy:true},
  tiktok:{video:true,shortVideo:true,scheduling:false,analytics:true,thumbnail:true,privacy:true},
  linkedin:{video:true,shortVideo:false,scheduling:false,analytics:true,thumbnail:true,privacy:true},
  x:{video:true,shortVideo:false,scheduling:false,analytics:true,thumbnail:false,privacy:false},
  threads:{video:true,shortVideo:true,scheduling:false,analytics:true,thumbnail:false,privacy:false},
  pinterest:{video:true,shortVideo:true,scheduling:false,analytics:true,thumbnail:true,privacy:false},
  reddit:{video:true,shortVideo:false,scheduling:false,analytics:false,thumbnail:false,privacy:false},
  bluesky:{video:true,shortVideo:true,scheduling:false,analytics:false,thumbnail:false,privacy:false},
  mastodon:{video:true,shortVideo:false,scheduling:true,analytics:false,thumbnail:false,privacy:true},
  snapchat:{video:true,shortVideo:true,scheduling:false,analytics:true,thumbnail:true,privacy:false},
  vimeo:{video:true,shortVideo:false,scheduling:false,analytics:true,thumbnail:true,privacy:true},
  twitch:{video:false,shortVideo:false,scheduling:true,analytics:true,thumbnail:false,privacy:false}
};

function env(name){return process.env[name]||'';}
function redirect(platform){ return env(`${platform.toUpperCase()}_REDIRECT_URI`) || `${config.appUrl}/api/oauth/${platform}/callback`; }
const oauth={
  youtube:{clientId:()=>env('YOUTUBE_CLIENT_ID'),clientSecret:()=>env('YOUTUBE_CLIENT_SECRET'),authorize:'https://accounts.google.com/o/oauth2/v2/auth',token:'https://oauth2.googleapis.com/token',scopes:['https://www.googleapis.com/auth/youtube.upload','https://www.googleapis.com/auth/youtube.readonly'],pkce:true},
  tiktok:{clientId:()=>env('TIKTOK_CLIENT_KEY'),clientSecret:()=>env('TIKTOK_CLIENT_SECRET'),authorize:'https://www.tiktok.com/v2/auth/authorize/',token:'https://open.tiktokapis.com/v2/oauth/token/',scopes:['user.info.basic','video.publish','video.upload'],pkce:true,clientIdParam:'client_key'},
  linkedin:{clientId:()=>env('LINKEDIN_CLIENT_ID'),clientSecret:()=>env('LINKEDIN_CLIENT_SECRET'),authorize:'https://www.linkedin.com/oauth/v2/authorization',token:'https://www.linkedin.com/oauth/v2/accessToken',scopes:['openid','profile','w_member_social'],pkce:false},
  x:{clientId:()=>env('X_CLIENT_ID'),clientSecret:()=>env('X_CLIENT_SECRET'),authorize:'https://x.com/i/oauth2/authorize',token:'https://api.x.com/2/oauth2/token',scopes:['tweet.read','tweet.write','users.read','offline.access'],pkce:true},
  pinterest:{clientId:()=>env('PINTEREST_APP_ID'),clientSecret:()=>env('PINTEREST_APP_SECRET'),authorize:'https://www.pinterest.com/oauth/',token:'https://api.pinterest.com/v5/oauth/token',scopes:['pins:read','pins:write','boards:read','user_accounts:read'],pkce:false}
};

export async function startOAuth(platform){
  const cfg=oauth[platform]; if(!cfg) throw new Error(`OAuth is not configured for ${platform} yet`); if(!cfg.clientId()) throw new Error(`Missing ${platform} client ID/key`);
  const state=randomId('st_'); const {verifier,challenge}=cfg.pkce?pkcePair():{verifier:null,challenge:null}; await query('INSERT INTO oauth_states(state,platform,verifier) VALUES($1,$2,$3)',[state,platform,verifier]);
  const u=new URL(cfg.authorize); u.searchParams.set(cfg.clientIdParam||'client_id',cfg.clientId()); u.searchParams.set('redirect_uri',redirect(platform)); u.searchParams.set('response_type','code'); u.searchParams.set('state',state); u.searchParams.set('scope',cfg.scopes.join(' '));
  if(platform==='youtube'){u.searchParams.set('access_type','offline');u.searchParams.set('prompt','consent');}
  if(cfg.pkce){u.searchParams.set('code_challenge',challenge);u.searchParams.set('code_challenge_method','S256');}
  return u.toString();
}

export async function finishOAuth(platform,code,state){
  const cfg=oauth[platform],st=await one('SELECT * FROM oauth_states WHERE state=$1',[state]); if(!cfg||!st||st.platform!==platform) throw new Error('Invalid OAuth state'); await query('DELETE FROM oauth_states WHERE state=$1',[state]);
  const body=new URLSearchParams({grant_type:'authorization_code',code,redirect_uri:redirect(platform),[cfg.clientIdParam||'client_id']:cfg.clientId()}); if(cfg.clientSecret())body.set('client_secret',cfg.clientSecret()); if(st.verifier)body.set('code_verifier',st.verifier);
  const headers={'content-type':'application/x-www-form-urlencoded'}; if(platform==='pinterest'&&cfg.clientSecret())headers.authorization='Basic '+Buffer.from(`${cfg.clientId()}:${cfg.clientSecret()}`).toString('base64');
  const res=await fetch(cfg.token,{method:'POST',headers,body}); const data=await res.json(); if(!res.ok)throw new Error(`OAuth token exchange failed: ${JSON.stringify(data)}`);
  const id=randomId('acct_'),exp=data.expires_in?new Date(Date.now()+Number(data.expires_in)*1000):null,enc=encryptJson(data,config.tokenEncryptionKey); await query(`INSERT INTO social_accounts(id,platform,display_name,username,account_type,status,encrypted_credentials,token_expires_at,last_sync) VALUES($1,$2,$3,$4,$5,'CONNECTED',$6,$7,NOW())`,[id,platform,`${platform} account`,null,'OAuth',enc,exp]); return{id,platform};
}

async function credentials(accountId){ const acct=await one('SELECT * FROM social_accounts WHERE id=$1',[accountId]); if(!acct?.encrypted_credentials)return{acct,token:null,creds:null}; const creds=decryptJson(acct.encrypted_credentials,config.tokenEncryptionKey); return{acct,token:creds.access_token,creds}; }

async function youtubePublish({target,mediaPath,mimeType}){
  const {token}=await credentials(target.account_id); if(!token)throw Object.assign(new Error('YouTube account has no access token; reconnect it.'),{retryable:false});
  const meta={snippet:{title:target.title||'Untitled',description:target.caption||''},status:{privacyStatus:'private'}};
  const init=await fetch('https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status',{method:'POST',headers:{authorization:`Bearer ${token}`,'content-type':'application/json','x-upload-content-type':mimeType},body:JSON.stringify(meta)});
  if(!init.ok)throw new Error(`YouTube upload session failed: ${await init.text()}`); const uploadUrl=init.headers.get('location'); if(!uploadUrl)throw new Error('YouTube did not return a resumable upload URL');
  const bytes=fs.readFileSync(mediaPath); const done=await fetch(uploadUrl,{method:'PUT',headers:{'content-type':mimeType,'content-length':String(bytes.length)},body:bytes}); const data=await done.json(); if(!done.ok)throw new Error(`YouTube upload failed: ${JSON.stringify(data)}`); return{externalId:data.id,externalUrl:`https://www.youtube.com/watch?v=${data.id}`};
}
async function tiktokPublish({target,publicMediaUrl}){
  const {token}=await credentials(target.account_id); if(!token)throw Object.assign(new Error('TikTok account has no access token; reconnect it.'),{retryable:false}); if(!publicMediaUrl)throw Object.assign(new Error('TikTok Direct Post requires R2_PUBLIC_BASE_URL with a verified public media domain.'),{retryable:false});
  const res=await fetch('https://open.tiktokapis.com/v2/post/publish/video/init/',{method:'POST',headers:{authorization:`Bearer ${token}`,'content-type':'application/json; charset=UTF-8'},body:JSON.stringify({post_info:{title:target.caption||'',privacy_level:'SELF_ONLY',disable_duet:false,disable_comment:false,disable_stitch:false},source_info:{source:'PULL_FROM_URL',video_url:publicMediaUrl}})}); const data=await res.json(); if(!res.ok||data.error?.code)throw new Error(`TikTok publish init failed: ${JSON.stringify(data)}`); return{externalId:data.data?.publish_id||randomId('tt_'),externalUrl:null};
}

export async function publishTarget(ctx){
  if(config.publishMode!=='live'||String(ctx.target.account_id||'').startsWith('mock_')){
    await new Promise(r=>setTimeout(r,300)); if((ctx.target.caption||'').includes('[fail-temporary]'))throw Object.assign(new Error('Simulated temporary network failure'),{retryable:true}); if((ctx.target.caption||'').includes('[fail-permanent]'))throw Object.assign(new Error('Simulated permanent validation failure'),{retryable:false}); return{externalId:randomId(`${ctx.target.platform}_`),externalUrl:`https://example.invalid/${ctx.target.platform}/${ctx.target.id}`};
  }
  if(ctx.target.platform==='youtube')return youtubePublish(ctx); if(ctx.target.platform==='tiktok')return tiktokPublish(ctx);
  throw Object.assign(new Error(`Live publishing for ${ctx.target.platform} requires its production adapter/app approval. The target is preserved for manual publishing rather than bypassing the official API.`),{retryable:false,actionRequired:true});
}
