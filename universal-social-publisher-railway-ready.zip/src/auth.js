import crypto from 'node:crypto';
import { one, query } from './db.js';
import { config } from './config.js';
import { randomId } from './crypto.js';

function parseCookies(req){ return Object.fromEntries(String(req.headers.cookie||'').split(';').map(v=>v.trim()).filter(Boolean).map(v=>{const i=v.indexOf('=');return [decodeURIComponent(v.slice(0,i)),decodeURIComponent(v.slice(i+1))]})); }
export function verifyPassword(password, encoded){
  const [kind,saltHex,hashHex]=String(encoded||'').split(':'); if(kind!=='scrypt'||!saltHex||!hashHex) return false;
  const candidate=crypto.scryptSync(password,Buffer.from(saltHex,'hex'),64); const expected=Buffer.from(hashHex,'hex');
  return candidate.length===expected.length && crypto.timingSafeEqual(candidate,expected);
}
export async function ensureOwner(){
  if(config.authDisabled || !config.ownerEmail || !config.ownerPasswordHash) return;
  const existing=await one('SELECT id FROM users WHERE email=$1',[config.ownerEmail.toLowerCase()]);
  if(!existing) await query('INSERT INTO users(id,email,password_hash,role) VALUES($1,$2,$3,$4)',[randomId('usr_'),config.ownerEmail.toLowerCase(),config.ownerPasswordHash,'OWNER']);
  else await query('UPDATE users SET password_hash=$1,updated_at=NOW() WHERE id=$2',[config.ownerPasswordHash,existing.id]);
}
export async function login(email,password){
  const user=await one('SELECT * FROM users WHERE email=$1',[String(email||'').toLowerCase()]);
  if(!user || !verifyPassword(password,user.password_hash)) return null;
  const sid=randomId('sess_'), csrf=randomId('csrf_');
  const expires=new Date(Date.now()+config.sessionDays*86400_000);
  await query('INSERT INTO sessions(id,user_id,csrf_token,expires_at) VALUES($1,$2,$3,$4)',[sid,user.id,csrf,expires]);
  return {sid,csrf,user:{id:user.id,email:user.email,role:user.role},expires};
}
export async function getSession(req){
  if(config.authDisabled) return {user:{id:'dev',email:'dev@local',role:'OWNER'},csrf:'dev'};
  const sid=parseCookies(req).usp_session; if(!sid) return null;
  return one(`SELECT s.id,s.csrf_token AS csrf,u.id AS user_id,u.email,u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.id=$1 AND s.expires_at>NOW()`,[sid]);
}
export async function logout(req){ const sid=parseCookies(req).usp_session; if(sid) await query('DELETE FROM sessions WHERE id=$1',[sid]); }
export function setSessionCookie(res,session){ const secure=config.appUrl.startsWith('https://')?'; Secure':''; res.setHeader('Set-Cookie',`usp_session=${encodeURIComponent(session.sid)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${config.sessionDays*86400}${secure}`); }
export function clearSessionCookie(res){ const secure=config.appUrl.startsWith('https://')?'; Secure':''; res.setHeader('Set-Cookie',`usp_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure}`); }
export function validCsrf(req,session){ if(config.authDisabled) return true; return req.headers['x-csrf-token']===session.csrf; }
