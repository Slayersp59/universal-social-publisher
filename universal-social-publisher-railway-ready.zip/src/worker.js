import { Worker } from 'bullmq';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { redisConnection } from './queue.js';
import { one, many, query, tx } from './db.js';
import { publishTarget } from './platforms.js';
import { downloadToFile, publicUrl } from './storage.js';
import { analyzeMedia } from './media.js';
import { randomId } from './crypto.js';

async function refreshPostStatus(postId){ const states=(await many('SELECT status FROM post_targets WHERE post_id=$1',[postId])).map(x=>x.status); let overall='QUEUED'; if(states.length&&states.every(x=>x==='PUBLISHED'))overall='PUBLISHED'; else if(states.some(x=>x==='ACTION_REQUIRED'))overall='ACTION_REQUIRED'; else if(states.some(x=>x==='PUBLISHING'))overall='PUBLISHING'; else if(states.some(x=>x==='RETRYING'))overall='RETRYING'; await query('UPDATE posts SET status=$1,updated_at=NOW() WHERE id=$2',[overall,postId]); }
async function publishJob(job){
  const target=await one(`SELECT pt.*,p.media_id,m.object_key,m.mime_type FROM post_targets pt JOIN posts p ON p.id=pt.post_id LEFT JOIN media_assets m ON m.id=p.media_id WHERE pt.id=$1`,[job.data.targetId]); if(!target)throw Object.assign(new Error('Target no longer exists'),{retryable:false}); if(target.status==='PUBLISHED')return{alreadyPublished:true};
  await query("UPDATE post_targets SET status='PUBLISHING',updated_at=NOW() WHERE id=$1",[target.id]); await refreshPostStatus(target.post_id);
  let tempDir=null,mediaPath=null;
  try{
    if(target.object_key){tempDir=fs.mkdtempSync(path.join(os.tmpdir(),'usp-pub-'));mediaPath=path.join(tempDir,'media');await downloadToFile(target.object_key,mediaPath);}
    const result=await publishTarget({target,mediaPath,mimeType:target.mime_type||'video/mp4',publicMediaUrl:target.object_key?publicUrl(target.object_key):null});
    await tx(async c=>{await c.query("UPDATE post_targets SET status='PUBLISHED',external_id=$1,external_url=$2,attempt_count=attempt_count+1,error=NULL,updated_at=NOW() WHERE id=$3",[result.externalId,result.externalUrl,target.id]);await c.query('INSERT INTO publication_attempts(id,target_id,attempt_no,status,message) VALUES($1,$2,$3,$4,$5)',[randomId('att_'),target.id,(target.attempt_count||0)+1,'PUBLISHED','Published successfully']);}); await refreshPostStatus(target.post_id); return result;
  }catch(e){
    const final=job.attemptsMade+1 >= (job.opts.attempts||1) || e.retryable===false; await query(`UPDATE post_targets SET status=$1,attempt_count=attempt_count+1,error=$2,updated_at=NOW() WHERE id=$3`,[final?'ACTION_REQUIRED':'RETRYING',String(e.message||e),target.id]); await query('INSERT INTO publication_attempts(id,target_id,attempt_no,status,message) VALUES($1,$2,$3,$4,$5)',[randomId('att_'),target.id,(target.attempt_count||0)+1,final?'FAILED':'RETRYING',String(e.message||e)]); await refreshPostStatus(target.post_id); if(final&&e.retryable===false)return{actionRequired:true,error:e.message}; throw e;
  }finally{if(tempDir)fs.rmSync(tempDir,{recursive:true,force:true});}
}
const connection=redisConnection();
const publicationWorker=new Worker('publishing',publishJob,{connection,concurrency:Number(process.env.PUBLISH_CONCURRENCY||3)});
const mediaWorker=new Worker('media-processing',job=>analyzeMedia(job.data.mediaId),{connection,concurrency:Number(process.env.MEDIA_CONCURRENCY||1)});
for(const w of [publicationWorker,mediaWorker]){w.on('completed',j=>console.log(`[worker] ${j.queueName}:${j.id} completed`));w.on('failed',(j,e)=>console.error(`[worker] ${j?.queueName}:${j?.id} failed`,e.message));}
async function shutdown(){await Promise.all([publicationWorker.close(),mediaWorker.close()]);process.exit(0);} process.on('SIGTERM',shutdown);process.on('SIGINT',shutdown);
console.log('Universal Social Publisher worker started');
