import pg from 'pg';
import { config } from './config.js';
const { Pool } = pg;
if (!config.databaseUrl) console.warn('DATABASE_URL is not set. Database operations will fail until it is configured.');
export const pool = new Pool({ connectionString: config.databaseUrl || undefined, max:10 });
export async function query(text, params=[]){ return pool.query(text, params); }
export async function one(text, params=[]){ const r=await pool.query(text,params); return r.rows[0] || null; }
export async function many(text, params=[]){ const r=await pool.query(text,params); return r.rows; }
export async function tx(fn){ const c=await pool.connect(); try{ await c.query('BEGIN'); const result=await fn(c); await c.query('COMMIT'); return result; }catch(e){ await c.query('ROLLBACK'); throw e; }finally{ c.release(); } }
export async function closeDb(){ await pool.end(); }
