# Universal Social Publisher — Railway Production Build

A production-oriented deployment package for the Universal Social Publisher dashboard. The application keeps the original **Connect Accounts → Upload Video → Select Platforms → Customize → Preview → Publish/Schedule → Track Status** workflow, but replaces development-only SQLite/local media/timers with deployable services.

## Production architecture

- **Railway Web service** — Node.js API + dashboard
- **Railway PostgreSQL** — durable users, sessions, accounts, media metadata, posts, publication state and audit logs
- **Railway Redis** — BullMQ durable publication/media queues
- **Railway Worker service** — FFmpeg/FFprobe processing and publishing jobs
- **Cloudflare R2** — master videos and generated variants
- **Official social APIs** — adapter layer; mock mode remains available while credentials/app reviews are being completed

The included Dockerfile installs FFmpeg and works for both the web and worker Railway services.

## What works now

- Owner login with scrypt password hashing
- HTTP-only secure session cookie and CSRF protection
- PostgreSQL migrations on startup
- Encrypted OAuth credential storage (AES-256-GCM)
- OAuth state validation and PKCE for configured providers
- Direct browser → R2 video upload using 15-minute presigned PUT URLs
- R2 presigned downloads
- FFprobe metadata extraction
- FFmpeg variants: 9:16, 1:1, 4:5, 16:9
- Redis/BullMQ publication queue
- Delayed scheduled publication jobs
- Exponential retries for retryable publication failures
- Per-destination status/failure isolation
- Mock adapters for immediate end-to-end testing
- YouTube OAuth + resumable upload live adapter
- TikTok OAuth + Direct Post initialization live adapter
- OAuth foundations for LinkedIn, X and Pinterest
- Manual/action-required state for platforms whose production adapter/app approval is not configured
- Dashboard API and audit log persistence
- Railway health endpoint

## Important social API limitation

No repository can ship working production credentials or bypass platform review. You must create your own developer apps and enter their client IDs/secrets in Railway. Some social networks must approve the app before they allow production publishing. The project deliberately marks unsupported/unapproved live targets as `ACTION_REQUIRED` instead of using scraping or browser automation.

## 1. Put this project in GitHub

Create a private repository and push the contents of this folder. **Do not commit `.env`.**

## 2. Create the Railway project

Create one Railway project, then add:

1. **PostgreSQL**
2. **Redis**
3. **Web service** from your GitHub repository
4. **Worker service** from the same GitHub repository

Railway will detect `Dockerfile` automatically.

### Web service

Use the default start command:

```bash
npm start
```

Set health check path:

```text
/api/health
```

### Worker service

Override its start command to:

```bash
npm run worker
```

The worker does not need a public domain.

## 3. Railway variables

Reference Railway's PostgreSQL and Redis connection URLs in **both Web and Worker services**:

```text
DATABASE_URL=<Railway PostgreSQL DATABASE_URL>
REDIS_URL=<Railway Redis REDIS_URL>
```

Then add:

```text
NODE_ENV=production
APP_URL=https://app.yourdomain.com
PUBLISH_MODE=mock
SEED_MOCK_DATA=true
TOKEN_ENCRYPTION_KEY=<strong random secret>
AUTH_DISABLED=false
OWNER_EMAIL=you@example.com
OWNER_PASSWORD_HASH=<generated hash>
```

Generate the password hash locally:

```bash
npm run hash-password -- "your very strong password"
```

Copy only the printed `scrypt:...` value into `OWNER_PASSWORD_HASH`.

Generate a token encryption secret with a password manager or, locally:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"
```

## 4. Cloudflare R2

Create a private bucket such as:

```text
universal-social-publisher
```

Create R2 API credentials with read/write access to that bucket and put these variables in **both Railway services**:

```text
R2_ACCOUNT_ID=
R2_BUCKET=universal-social-publisher
R2_ACCESS_KEY_ID=
R2_SECRET_ACCESS_KEY=
```

For browser uploads, configure the bucket CORS policy using `r2-cors.json`, replacing `https://app.YOURDOMAIN.com` with your real app domain.

`R2_PUBLIC_BASE_URL` is optional for normal mock/YouTube operation. TikTok's `PULL_FROM_URL` live path needs a public/verified media URL, so configure a suitable R2 custom domain and then set:

```text
R2_PUBLIC_BASE_URL=https://media.yourdomain.com
```

## 5. Add your domain

In Railway Web service → **Settings → Networking → Custom Domain**, add:

```text
app.yourdomain.com
```

Add the DNS record Railway gives you. Keep WordPress on the root domain:

```text
yourdomain.com      → WordPress
app.yourdomain.com  → Railway app
```

Set `APP_URL=https://app.yourdomain.com` before configuring OAuth providers.

## 6. Test in mock mode first

Leave:

```text
PUBLISH_MODE=mock
```

Sign in at:

```text
https://app.yourdomain.com
```

Upload a real video. The expected flow is:

1. Web service creates a presigned R2 upload URL.
2. Browser uploads the video directly to R2.
3. Web service queues `media-processing`.
4. Worker runs FFprobe and FFmpeg.
5. Media metadata and variants appear in PostgreSQL/R2.
6. Create a post and select mock destinations.
7. Publish now or schedule it.
8. BullMQ delivers each target independently to the worker.
9. Dashboard updates per destination.

To exercise failure handling in mock mode, include:

```text
[fail-temporary]
```

in a target caption to test retries, or:

```text
[fail-permanent]
```

to test `ACTION_REQUIRED`.

## 7. Enable YouTube

Create a Google Cloud OAuth application and set its redirect URI to:

```text
https://app.yourdomain.com/api/oauth/youtube/callback
```

Add:

```text
YOUTUBE_CLIENT_ID=
YOUTUBE_CLIENT_SECRET=
YOUTUBE_REDIRECT_URI=https://app.yourdomain.com/api/oauth/youtube/callback
```

After connecting a real account, switch:

```text
PUBLISH_MODE=live
```

Only non-mock accounts use live publishing; seeded mock accounts continue using the mock adapter.

## 8. Enable TikTok

Configure TikTok Login Kit / Content Posting for your developer app and callback:

```text
https://app.yourdomain.com/api/oauth/tiktok/callback
```

Set:

```text
TIKTOK_CLIENT_KEY=
TIKTOK_CLIENT_SECRET=
TIKTOK_REDIRECT_URI=https://app.yourdomain.com/api/oauth/tiktok/callback
R2_PUBLIC_BASE_URL=https://media.yourdomain.com
```

TikTok production publishing is subject to TikTok's current developer approval/audit and domain requirements.

## Other social platforms

The common adapter architecture is in `src/platforms.js`. OAuth foundations are present for LinkedIn, X and Pinterest. Meta/Instagram/Facebook credentials are reserved in `.env.example`, but production publishing needs the exact account/product permissions and app-review configuration for your Meta app before enabling that live adapter. Until then, use mock mode or the `ACTION_REQUIRED` manual fallback rather than unofficial automation.

## API

Public:

- `GET /api/health`
- `POST /api/auth/login`
- `GET /api/oauth/:platform/callback`

Authenticated:

- `GET /api/auth/session`
- `POST /api/auth/logout`
- `GET /api/platforms`
- `GET /api/accounts`
- `POST /api/accounts/mock/connect`
- `POST /api/media/upload-url`
- `POST /api/media/complete`
- `GET /api/media`
- `GET /api/media/:id/download`
- `POST /api/posts`
- `GET /api/posts`
- `GET /api/posts/:id`
- `POST /api/posts/:id/publish`
- `GET /api/dashboard`
- `POST /api/oauth/:platform/start`

Authenticated mutating API requests require the `X-CSRF-Token` returned by `/api/auth/session`.

## Local production-style development

You need Node 22+, PostgreSQL, Redis, FFmpeg and an R2 bucket (or S3-compatible equivalent configured with the R2 environment variables).

```bash
npm install
cp .env.example .env
npm run db:migrate
npm run db:seed
npm start
```

In another terminal:

```bash
npm run worker
```

## Security notes

- Never commit `.env`.
- OAuth tokens are encrypted before PostgreSQL storage.
- Refresh/access tokens are never returned by `/api/accounts`.
- R2 credentials never reach the browser.
- Browser uploads receive only short-lived object-specific presigned URLs.
- Session cookies are HTTP-only, SameSite=Lax, and Secure on HTTPS.
- OAuth state is persisted and validated.
- PKCE is used where configured.
- The worker logs normalized messages rather than token payloads.
- Keep Railway PostgreSQL/Redis private to the project where possible.

## Files most relevant to deployment

```text
Dockerfile
railway.toml
.env.example
r2-cors.json
migrations/001_init.sql
src/server.js
src/worker.js
src/storage.js
src/queue.js
src/media.js
src/platforms.js
```
